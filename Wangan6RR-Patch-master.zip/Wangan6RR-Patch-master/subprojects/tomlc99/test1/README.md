How to run the tests
===

```
% bash build.sh
% bash run.sh
Test: array-mixed-types-arrays-and-ints (invalid)

Expected an error, but no error was reported.
-------------------------------------------------------------------------------
Test: array-mixed-types-ints-and-floats (invalid)

Expected an error, but no error was reported.
-------------------------------------------------------------------------------
Test: array-mixed-types-strings-and-ints (invalid)

Expected an error, but no error was reported.

129 passed, 3 failed
```

Note: toml version 1.0 allows mixed types in arrays.
